var venn = venn || {'version' : '0.2'};
