(function(lib) {
    if (typeof module === "undefined" || typeof module.exports === "undefined") {
        window.venn = lib;
    } else {
        module.exports = lib;
    }
})(venn);
